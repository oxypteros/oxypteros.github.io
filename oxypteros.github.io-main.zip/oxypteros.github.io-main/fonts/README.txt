In this folder you can put your custom local fonts that you want to use with Alpha theme.
For more info check the https://oxylab.ml/alpha-theme/hugo/settings/fonts