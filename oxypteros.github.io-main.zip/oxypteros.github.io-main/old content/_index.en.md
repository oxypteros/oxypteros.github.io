+++
title = "Laboratory"
date = 2022-11-16T17:19:58+01:00
draft = false
type = "lab"
layout = "index-lab"
contentInfo = false
  contentDisclaimer = ""
  contentCopy = false
  author = ""
  contentLicense = "" # Value All | None |
bottomIcon = "franki"
toc = false
multipart = false
  previousPartUrl = ""
  nextPartUrl = ""
subtitle = "&#8220;It's moving, it's alive, it's alive, IT'S ALIVE!&#8221;"
# SEO #
description = ""
## OGP ##
ogpType = "article"
+++

