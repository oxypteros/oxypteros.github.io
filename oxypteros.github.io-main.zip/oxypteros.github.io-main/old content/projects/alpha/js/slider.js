Split(['#left', '#right'], {
  minSize: 0,
  gutterSize: 10,
  snapOffset: 100,
})