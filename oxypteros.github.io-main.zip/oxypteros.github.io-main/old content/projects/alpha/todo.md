story

section with secondary color for copy check 
https://www.starbucksathome.com/it/storia/chi-siamo

list 

every story different color in a list
https://www.starbucksathome.com/it/