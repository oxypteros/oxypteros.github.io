+++
title = "Projects"
date = 2022-11-19T16:07:51+01:00
draft = false
featured = false
type = "lab"
layout = "index-lab"
contentInfo = false
  contentDisclaimer = ""
  contentCopy = false
  author = ""
  contentLicense = "" # Value All | None |
paragraphIndent = true
toc = false
multipart = false
  previousPartUrl = ""
  nextPartUrl = ""
subtitle = "&#8220;Mumm-Ra is in control here.&#8221;"
bgImgTag = "projects"
bottomIcon = "franki-dead"
# SEO #
description = "Work in progress. Beware unstable and ugly stuff."
## OGP ##
ogpType = "article"
+++

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ‘Content here, content here’, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ’lorem ipsum’ will uncover many web sites still in their infancy.