+++
title = "Alpha Theme"
date = 2022-11-16T17:16:39+01:00
draft = false
featured = true
contentInfo = false
  contentDisclaimer = ""
  contentCopy = false
  author = ""
  contentLicense = "" # Value All | None |
toc = false
multipart = false
  previousPartUrl = ""
  nextPartUrl = ""
subtitle = "&#8220;Mumm-Ra is in control here.&#8221;"
downloadUrl = "#1"
demoUrl = "#2"
labCardSummary = "A responsive, mobile first, fast, minimalistic theme for hugo. Focused especially on the written content with several behind the scenes optimizations for readability and accessibility. Ideal for personal sites, blogs and any written content projects."
bottomIcon = "franki-dead"
# SEO #
description = ""
## OGP ##
ogpType = "article"
+++

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
