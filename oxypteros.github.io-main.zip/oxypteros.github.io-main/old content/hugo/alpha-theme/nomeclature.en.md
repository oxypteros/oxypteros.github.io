+++
title = "Nomeclature"
date = 2022-11-14T12:01:55+01:00
draft = false
featured = true
# SEO #
## OGP ##
ogpType = "article"
+++

## Nomeclature Rules

FILE NAME-MAIN FOLDER_SECONDARY FOLDER