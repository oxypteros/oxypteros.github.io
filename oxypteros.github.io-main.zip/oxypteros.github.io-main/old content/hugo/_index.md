+++
title = "Hugo"
date = 2022-11-18T15:52:46+01:00
draft = false
type = "lab"
layout = "list-lab"
contentInfo = false
  contentDisclaimer = ""
  contentCopy = false
  author = "oxylab.ml"
  contentLicense = "" # Value All | None |
paragraphIndent = false
bottomIcon = "hugo"
toc = false
multipart = false
  previousPartUrl = ""
  nextPartUrl = ""
subtitle = "&#8220;Can make the Kessel run in 13 parsecs&#8220;"
bgImgTag = "hugo"
# SEO #
description = "Themes, install instructions and some tutorials."
## OGP ##
ogpType = "article"
+++
[Hugo](https://gohugo.io "Homepage of the hugo framework") is the world's fastest framework for building websites. In essence is a static site generator written in Go. It may be famous for the speed but we just love the flexibility it offers.

In this section you will find themes that we created or port/fork for hugo and their respective step by step installation guides/tutorials for the, **inexperienced**, average user. 
